# Contributing to DynaSphere USD Schemas

Maintainer: USTB_Ai3D_theLazyFo0l.

Keep schema definitions in `dynasphere_usd_schemas/generatedSchema.usda` and registration metadata in `dynasphere_usd_schemas/plugInfo.json` consistent. Include both resources in built distributions.

Use Python 3.10 through 3.13 with an OpenUSD runtime. Run the unit tests with `python -m unittest discover -v -s tests`, then build the distributions with `python -m build`.

Project repository: https://github.com/theLazyFo0l/DynaSphere-assets
