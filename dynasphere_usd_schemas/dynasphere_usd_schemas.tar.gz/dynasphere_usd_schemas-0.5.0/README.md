# DynaSphere USD Schemas

OpenUSD schema definitions for the DynaSphere physics engine.

Author and maintainer: **USTB_Ai3D_theLazyFo0l**.

This package is a DynaSphere namespace port of the upstream
[newton-usd-schemas 0.5.0](https://pypi.org/project/newton-usd-schemas/0.5.0/)
schema definitions. It is distributed under Apache-2.0.

## Package contents

- Distribution: `dynasphere-usd-schemas`.
- Python module: `dynasphere_usd_schemas`.
- OpenUSD plugin: `dynasphere`.
- Schema types: `DynaSphere*`, including `DynaSphereSceneAPI`,
  `DynaSphereMassAPI`, and `DynaSphereKaminoSceneAPI`.
- Authored properties: `dynasphere:*`.

The schemas are codeless: the distribution contains Python registration code,
`plugInfo.json`, and `generatedSchema.usda`, with no compiled plugin library.

## Requirements

Use Python **3.10, 3.11, 3.12, or 3.13** with an OpenUSD Python runtime such as
`usd-core`. This version retains the upstream Python compatibility range.

## Installation

Inside an environment using a supported Python version, install the wheel:

```console
python -m pip install usd-core
python -m pip install ./dist/dynasphere_usd_schemas-0.5.0-py3-none-any.whl
```

Or install directly from the extracted source directory:

```console
python -m pip install .
```

## Registration and usage

Import the package before the first use of `Usd.SchemaRegistry`:

```python
import dynasphere_usd_schemas
from pxr import Usd, UsdPhysics

stage = Usd.Stage.CreateInMemory()
scene = UsdPhysics.Scene.Define(stage, '/scene')
prim = scene.GetPrim()
prim.ApplyAPI('DynaSphereSceneAPI')
prim.GetAttribute('dynasphere:timeStepsPerSecond').Set(500)
```

The package registers DynaSphere schema names and properties. Assets authored
with the upstream `Newton*` schemas and `newton:*` properties require a separate
asset migration or importer compatibility layer; installing this renamed package
does not automatically rewrite existing assets.

## Development and packaging

```console
python -m unittest discover -v -s tests
python -m build
```

Both registration resources are included in the wheel. The source archive also
contains the tests and build configuration.

## Repository and license

Repository: https://github.com/theLazyFo0l/DynaSphere-assets

Upstream source: https://github.com/newton-physics/newton-usd-schemas

Copyright (c) 2026 USTB_Ai3D_theLazyFo0l.
See `LICENSE.md` for the Apache-2.0 license text.
