# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

__version__ = "0.5.0"
