# Citation Guide

```bibtex
@software{dynasphere-usd-schemas,
  title = {DynaSphere USD Schemas},
  author = {{USTB_Ai3D_theLazyFo0l}},
  year = {2026},
  url = {https://github.com/theLazyFo0l/DynaSphere-assets},
  license = {Apache-2.0}
}
```
