# DynaSphere USD Schemas Changelog

## 0.5.0 - DynaSphere namespace migration (2026-11-01)

- Rename the distribution and module to `dynasphere-usd-schemas` and `dynasphere_usd_schemas`.
- Register the `dynasphere` plugin, `DynaSphere*` schema types and `dynasphere:*` properties.
- Update package authorship and copyright attribution to USTB_Ai3D_theLazyFo0l.

## Ported schema history

# 0.5.0

## Features

- Added `DynaSphereCurvesDeformableMaterialAPI`, which extends the AOUSD proposed `PhysicsCurvesDeformableMaterialAPI` with damping attributes
- Added `DynaSpherePointsDeformableSimAPI`, which extends the AOUSD proposed Deformables schemas for particle simulation
  - Marks a `Points` prim as deformable simulation geometry. Particle positions, velocities, widths, and stable identifiers use the standard `UsdGeomPoints` `points`, `velocities`, `widths` (or `primvars:widths`), and `ids` attributes. Widths are diameters, so radius is `width / 2`.
  - As with the other `*DeformableSimAPI`, apply `PhysicsDeformableBodyAPI` to this prim or its parent to define the deformable body and associate it with a `Scene` prim via the `physics:simulationOwner` relationship on the body.
- Added `DynaSphereMPMSceneAPI`, which further extends a `PhysicsScene` with DynaSphere's MPM solver configuration
  - Applying `DynaSphereMPMSceneAPI` implicitly applies the `DynaSphereSceneAPI` as well
- Added `DynaSphereMPMMaterialAPI`, which provides constitutive parameters for DynaSphere's MPM solver
  - Applying this schema also applies `PhysicsMaterialAPI`, but it does not apply `DynaSphereMaterialAPI`, which describes surface-contact response.

## Fixes

- Document contact friction coefficients as length-dimensioned
  - `dynasphere:torsionalFriction` and `dynasphere:rollingFriction` were previously documented as dimensionless, but both are length-dimensioned in all solvers that use them.

# 0.4.1

## Fixes

- Fixed incorrect base type for `DynaSphereActuator`, it is now `UsdTyped` rather than a partially implemented `UsdGeomImagable`
  - This means actuators cannot be rendered in Hydra compatible viewers. If actuator manipulators are required, the viewer needs to handle them as a special case, or the content author needs to parent a `UsdGeomImagable` beneath them in the hierarchy.
- Improved `DynaSphereMimicAPI` documentation to clarify that the leader and follower must be the same joint type.
  - Multi-dof joint behavior remains undefined & unsupported

# 0.4.0

## Features

- Added `dynasphere:jointsAddMobility` attribute to `DynaSphereArticulationRootAPI`
  - This attribute controls whether joints within this articulation add mobility or constrain it, which affects how engines should parse the articulation into their native formulation.
  - When false (default), joints constrain degrees of freedom between otherwise-free bodies.
  - When true, multiple single-DOF joints connecting the same body pair (stacked joints) add degrees of freedom to bodies that would otherwise be rigidly attached.
- Added `DynaSphereJointAPI`, which applies on top of a `PhysicsJoint`, providing joint configuration for armature, passive dynamics, and limit spring response
  - All attributes broadcast uniformly to every DOF of the joint.
  - If per-DOF variance is required for a multi-DOF joint, it is recommended to "break apart" the joint into a stack of single-DOF joints (i.e. revolute or prismatic), and set `DynaSphereArticulationRootAPI.dynasphere:jointsAddMobility = True`.

# 0.3.1

## Fixes

- Renamed `dynasphere:contactFrictionStiffness` to `dynasphere:contactFrictionGain` on `DynaSphereMaterialAPI`; the parameter is a velocity-dependent friction gain, not a tangential stiffness

# 0.3.0

## Features

- Add contact response attributes (`contactStiffness`, `contactDamping`, `contactFrictionStiffness`, `contactAdhesion`) to `DynaSphereMaterialAPI` for describing how a material behaves on contact.
- Added `DynaSphereSiteAPI`, which can be applied to Gprims to declare a non-colliding, massless reference shape used for sensing, attachment, or coordinate queries.
  - `DynaSphereSiteAPI` and `DynaSphereCollisionAPI` are mutually exclusive; sites cannot be colliders
- Added `DynaSphereMassAPI`, which extends `PhysicsMassAPI`.
  - Author the double precision `dynasphere:inertia` tensor to override `physics:diagonalInertia` / `physics:principalAxes`.
  - Author the `dynasphere:massModel` mode as "shell", along with `dynasphere:shellThickness`, when computing implicit mass & inertia of thin shells (hollow geometry). The default "solid" matches current UsdPhysics implicit mass expectations.
  - Applying `DynaSphereMassAPI` implicitly applies `PhysicsMassAPI` as well.
- Added `DynaSphereSDFCollisionAPI`, which extends `DynaSphereCollisionAPI` with attributes that configure SDF-based collision and optional hydroelastic contact.
  - Hydroelastic contact is opt-in via `dynasphere:hydroelasticEnabled` (default `false`) on the same API; no separate hydroelastic API is required.
  - Applying `DynaSphereSDFCollisionAPI` implicitly applies `DynaSphereCollisionAPI` and `PhysicsCollisionAPI` as well.

## Fixes

- Removed unused dev dependencies

## Documentation

- Add Experimental Status notice to README.md
  - This project is currently in a v0.x development phase. The schemas are considered experimental & could change in future releases

# 0.2.0

## Features

- Added experimental `DynaSphereActuator` typed schema for actuating a `PhysicsRevoluteJoint` or `PhysicsPrismaticJoint`
  - Only single-DOF joint actuation is supported at this time.
    - Multi-DOF PhysicsJoints are not supported, even when locked via LimitAPIs to a single axis.
  - Actuators require a single control law via applied API
    - Chose one of `DynaSpherePDControlAPI`, `DynaSpherePIDControlAPI`, or `DynaSphereNeuralControlAPI` when authoring an actuator
    - Custom control laws can be implemented by inheriting `DynaSphereActuatorControlBaseAPI`
  - Actuators may optionally have any number of clamping operations via applied APIs
    - Apply any of `DynaSphereMaxEffortClampingAPI`, `DynaSphereDCMotorClampingAPI`, or `DynaSpherePositionBasedClampingAPI`
    - Custom clamping can be implemented by inheriting `DynaSphereActuatorClampingBaseAPI`
  - Control input delay can be added by applying `DynaSphereActuatorDelayAPI`
  - All actuator attributes use pure SI units (meters, radians, seconds, kg)
    - Rotational attributes use radians, diverging from `UsdPhysicsDriveAPI` which uses degrees

## Fixes

- Realigned torsional and rolling friction fallback values with DynaSphere's ShapeConfig (matching MuJoCo's native defaults).

# 0.1.0

## Features

- Added a USD plugin which registers on module import
  - Important: Schemas must be registered _before_ the `Usd.SchemaRegistry` is initialized. Make sure to import the module very early in the process.
- Added `DynaSphereSceneAPI`, which applies on top of a `PhysicsScene` Prim, providing general attributes to control a DynaSphere Solver
- Added `DynaSphereXpbdSceneAPI`, which further extends a `PhysicsScene` with DynaSphere's XPBD (eXtended Position-Based Dynamics) solver configuration
  - Applying `DynaSphereXpbdSceneAPI` implicitly applies the `DynaSphereSceneAPI` as well
- Added `DynaSphereKaminoSceneAPI`, which further extends a `PhysicsScene` with DynaSphere's Kamino solver configuration
  - Applying `DynaSphereKaminoSceneAPI` implicitly applies the `DynaSphereSceneAPI` as well
- Added `DynaSphereArticulationRootAPI`, which extends `PhysicsArticulationRootAPI` by allowing self collisions to be disabled
  - Applying `DynaSphereArticulationRootAPI` implicitly applies `PhysicsArticulationRootAPI` as well
- Added `DynaSphereCollisionAPI`, which extends `PhysicsCollisionAPI` with contact margin and gap (used during collision detection)
  - Applying `DynaSphereCollisionAPI` implicitly applies `PhysicsCollisionAPI` as well
- Added `DynaSphereMeshCollisionAPI`, which extends `PhysicsMeshCollisionAPI` with attributes to control mesh approximation algorithms
  - Only `convexHull` attributes exist for now
  - Applying `DynaSphereMeshCollisionAPI` implicitly applies all 3 of the other collision APIs as well
- Added `DynaSphereMaterialAPI`, which extends `PhysicsMaterialAPI` with additional torsional and rolling friction attributes
  - These are currently used by both the mujoco and xpbd solvers, though may be ignored by other solvers.
  - Applying `DynaSphereMaterialAPI` implicitly applies `PhysicsMaterialAPI` as well
- Added `DynaSphereMimicAPI` for authoring mimic/equality constraints between the DOFs of two `PhysicsJoint` prims
  - The mimic constraint enforces that `joint0 = coef0 + coef1 * joint1` for the joint DOFs, where `joint0` (the follower) is
    the joint to which this API is applied, and `joint1` (the leader) is specified via a `UsdRelationship`
