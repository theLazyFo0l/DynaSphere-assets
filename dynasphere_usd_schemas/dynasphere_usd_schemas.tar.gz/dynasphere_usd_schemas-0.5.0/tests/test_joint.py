# SPDX-FileCopyrightText: Copyright (c) 2026 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import math
import unittest

from pxr import Plug, Usd, UsdPhysics

import dynasphere_usd_schemas  # noqa: F401

USD_HAS_LIMITS = Usd.GetVersion() >= (0, 25, 11)


class TestDynaSphereJointAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.revolute: Usd.Prim = UsdPhysics.RevoluteJoint.Define(self.stage, "/Revolute").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsJointAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsJointAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsJointAPI")
        self.assertEqual(schema_type, "DynaSphereJointAPI")

    def test_api_application(self):
        self.assertFalse(self.revolute.HasAPI("DynaSphereJointAPI"))
        self.revolute.ApplyAPI("DynaSphereJointAPI")
        self.assertTrue(self.revolute.HasAPI("DynaSphereJointAPI"))

        self.assertTrue(self.revolute.HasAttribute("dynasphere:armature"))
        self.assertTrue(self.revolute.HasAttribute("dynasphere:damping"))
        self.assertTrue(self.revolute.HasAttribute("dynasphere:friction"))
        self.assertTrue(self.revolute.HasAttribute("dynasphere:velocityLimit"))
        self.assertTrue(self.revolute.HasAttribute("dynasphere:limitStiffness"))
        self.assertTrue(self.revolute.HasAttribute("dynasphere:limitDamping"))

    def test_api_application_prismatic(self):
        prismatic = UsdPhysics.PrismaticJoint.Define(self.stage, "/Prismatic").GetPrim()
        self.assertTrue(prismatic.CanApplyAPI("DynaSphereJointAPI"))
        prismatic.ApplyAPI("DynaSphereJointAPI")
        self.assertTrue(prismatic.HasAPI("DynaSphereJointAPI"))

    def test_api_application_spherical(self):
        spherical = UsdPhysics.SphericalJoint.Define(self.stage, "/Spherical").GetPrim()
        self.assertTrue(spherical.CanApplyAPI("DynaSphereJointAPI"))
        spherical.ApplyAPI("DynaSphereJointAPI")
        self.assertTrue(spherical.HasAPI("DynaSphereJointAPI"))

    def test_api_application_d6(self):
        d6 = UsdPhysics.Joint.Define(self.stage, "/D6").GetPrim()
        self.assertTrue(d6.CanApplyAPI("DynaSphereJointAPI"))
        d6.ApplyAPI("DynaSphereJointAPI")
        self.assertTrue(d6.HasAPI("DynaSphereJointAPI"))

    def test_api_limitations(self):
        xform: Usd.Prim = self.stage.DefinePrim("/NotJoint", "Xform")
        self.assertFalse(xform.CanApplyAPI("DynaSphereJointAPI"))

    def test_armature(self):
        self.revolute.ApplyAPI("DynaSphereJointAPI")
        attr = self.revolute.GetAttribute("dynasphere:armature")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        success = attr.Set(0.01)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.01)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_damping(self):
        self.revolute.ApplyAPI("DynaSphereJointAPI")
        attr = self.revolute.GetAttribute("dynasphere:damping")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        success = attr.Set(5.0)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 5.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_friction(self):
        self.revolute.ApplyAPI("DynaSphereJointAPI")
        attr = self.revolute.GetAttribute("dynasphere:friction")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        success = attr.Set(0.5)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_velocity_limit(self):
        self.revolute.ApplyAPI("DynaSphereJointAPI")
        attr = self.revolute.GetAttribute("dynasphere:velocityLimit")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), math.inf)

        success = attr.Set(360.0)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 360.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_limit_stiffness(self):
        self.revolute.ApplyAPI("DynaSphereJointAPI")
        attr = self.revolute.GetAttribute("dynasphere:limitStiffness")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(174.5)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 174.5)

    def test_limit_damping(self):
        self.revolute.ApplyAPI("DynaSphereJointAPI")
        attr = self.revolute.GetAttribute("dynasphere:limitDamping")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(0.1745)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.1745)


if __name__ == "__main__":
    unittest.main()
