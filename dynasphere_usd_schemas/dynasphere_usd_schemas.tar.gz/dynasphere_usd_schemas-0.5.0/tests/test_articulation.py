# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import unittest

from pxr import Plug, Usd, UsdGeom

import dynasphere_usd_schemas  # noqa: F401


class TestDynaSphereArticulationRootAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = UsdGeom.Xform.Define(self.stage, "/Articulation").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsArticulationRootAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsArticulationRootAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsArticulationRootAPI")
        self.assertEqual(schema_type, "DynaSphereArticulationRootAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("PhysicsArticulationRootAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereArticulationRootAPI"))
        self.prim.ApplyAPI("DynaSphereArticulationRootAPI")
        self.assertTrue(self.prim.HasAPI("PhysicsArticulationRootAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereArticulationRootAPI"))

        self.assertTrue(self.prim.HasAttribute("dynasphere:selfCollisionEnabled"))

    def test_self_collision_enabled(self):
        self.assertFalse(self.prim.HasAttribute("dynasphere:selfCollisionEnabled"))

        self.prim.ApplyAPI("DynaSphereArticulationRootAPI")
        attr = self.prim.GetAttribute("dynasphere:selfCollisionEnabled")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), True)

        success = attr.Set(False)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), False)

    def test_joints_add_mobility_default(self):
        self.prim.ApplyAPI("DynaSphereArticulationRootAPI")
        attr = self.prim.GetAttribute("dynasphere:jointsAddMobility")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), False)

    def test_joints_add_mobility_enabled(self):
        self.prim.ApplyAPI("DynaSphereArticulationRootAPI")
        attr = self.prim.GetAttribute("dynasphere:jointsAddMobility")
        success = attr.Set(True)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), True)


if __name__ == "__main__":
    unittest.main()
