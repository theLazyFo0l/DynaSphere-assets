# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import unittest

from pxr import Plug, Usd, UsdPhysics

import dynasphere_usd_schemas  # noqa: F401


class TestDynaSphereMimicAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.joint: Usd.Prim = UsdPhysics.RevoluteJoint.Define(self.stage, "/Joint").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsMimicAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsMimicAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsMimicAPI")
        self.assertEqual(schema_type, "DynaSphereMimicAPI")

    def test_api_application(self):
        self.assertFalse(self.joint.HasAPI("DynaSphereMimicAPI"))
        self.joint.ApplyAPI("DynaSphereMimicAPI")
        self.assertTrue(self.joint.HasAPI("DynaSphereMimicAPI"))

        self.assertTrue(self.joint.HasAttribute("dynasphere:mimicEnabled"))
        self.assertTrue(self.joint.HasRelationship("dynasphere:mimicJoint"))
        self.assertTrue(self.joint.HasAttribute("dynasphere:mimicCoef0"))
        self.assertTrue(self.joint.HasAttribute("dynasphere:mimicCoef1"))

    def test_api_application_prismatic(self):
        prismatic = UsdPhysics.PrismaticJoint.Define(self.stage, "/Prismatic").GetPrim()
        self.assertTrue(prismatic.CanApplyAPI("DynaSphereMimicAPI"))
        prismatic.ApplyAPI("DynaSphereMimicAPI")
        self.assertTrue(prismatic.HasAPI("DynaSphereMimicAPI"))

    def test_api_application_spherical(self):
        spherical = UsdPhysics.SphericalJoint.Define(self.stage, "/Spherical").GetPrim()
        self.assertTrue(spherical.CanApplyAPI("DynaSphereMimicAPI"))
        spherical.ApplyAPI("DynaSphereMimicAPI")
        self.assertTrue(spherical.HasAPI("DynaSphereMimicAPI"))

    def test_api_application_d6(self):
        d6 = UsdPhysics.Joint.Define(self.stage, "/D6").GetPrim()
        self.assertTrue(d6.CanApplyAPI("DynaSphereMimicAPI"))
        d6.ApplyAPI("DynaSphereMimicAPI")
        self.assertTrue(d6.HasAPI("DynaSphereMimicAPI"))

    def test_api_limitations(self):
        xform: Usd.Prim = self.stage.DefinePrim("/NotJoint", "Xform")
        self.assertFalse(xform.CanApplyAPI("DynaSphereMimicAPI"))

    def test_enabled(self):
        self.assertFalse(self.joint.HasAttribute("dynasphere:mimicEnabled"))

        self.joint.ApplyAPI("DynaSphereMimicAPI")
        attr = self.joint.GetAttribute("dynasphere:mimicEnabled")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), True)

        success = attr.Set(False)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), False)

    def test_coef0(self):
        self.assertFalse(self.joint.HasAttribute("dynasphere:mimicCoef0"))

        self.joint.ApplyAPI("DynaSphereMimicAPI")
        attr = self.joint.GetAttribute("dynasphere:mimicCoef0")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        success = attr.Set(1.5)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 1.5)

        # Negative offsets are valid
        success = attr.Set(-0.5)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), -0.5)

    def test_coef1(self):
        self.assertFalse(self.joint.HasAttribute("dynasphere:mimicCoef1"))

        self.joint.ApplyAPI("DynaSphereMimicAPI")
        attr = self.joint.GetAttribute("dynasphere:mimicCoef1")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 1.0)

        success = attr.Set(2.0)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 2.0)

        # Negative scale factors are valid (reverse direction)
        success = attr.Set(-1.0)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), -1.0)

        # Zero is valid (constant position/angle)
        success = attr.Set(0.0)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 0.0)


if __name__ == "__main__":
    unittest.main()
