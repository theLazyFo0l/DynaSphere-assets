# SPDX-FileCopyrightText: Copyright (c) 2026 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import math
import unittest

from pxr import Plug, Usd, UsdPhysics, Vt

import dynasphere_usd_schemas  # noqa: F401

USD_HAS_LIMITS = Usd.GetVersion() >= (0, 25, 11)


class TestDynaSphereMPMSceneAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.scene: Usd.Prim = UsdPhysics.Scene.Define(self.stage, "/Scene").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsMPMSceneAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsMPMSceneAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsMPMSceneAPI")
        self.assertEqual(schema_type, "DynaSphereMPMSceneAPI")

    def test_api_application(self):
        self.assertTrue(self.scene.CanApplyAPI("DynaSphereMPMSceneAPI"))
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        self.assertTrue(self.scene.HasAPI("DynaSphereSceneAPI"))
        self.assertTrue(self.scene.HasAPI("DynaSphereMPMSceneAPI"))
        self.assertTrue(self.scene.HasAttribute("dynasphere:maxSolverIterations"))
        self.assertFalse(self.scene.HasAttribute("dynasphere:mpm:maxIterations"))

    def test_api_limitations(self):
        prim: Usd.Prim = self.stage.DefinePrim("/NotScene", "Xform")
        self.assertFalse(prim.CanApplyAPI("DynaSphereMPMSceneAPI"))

    def test_tolerance(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:tolerance")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 1.0e-4, places=7)

        self.assertTrue(attr.Set(1.0e-5))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 1.0e-5, places=7)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_rheology_solvers(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:rheologySolvers")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), Vt.TokenArray(["auto"]))

        solvers = Vt.TokenArray(["conjugate-gradient", "auto"])
        self.assertTrue(attr.Set(solvers))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), solvers)
        self.assertEqual(
            set(attr.GetMetadata("allowedTokens")),
            {
                "auto",
                "gauss-seidel",
                "gauss-seidel-soa",
                "gauss-seidel-batched",
                "jacobi",
                "conjugate-gradient",
                "conjugate-residual",
                "generalized-minimal-residual",
            },
        )

    def test_voxel_size(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:voxelSize")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        self.assertTrue(attr.Set(0.05))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.05)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_grid_type(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:gridType")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "sparse")

        self.assertTrue(attr.Set("dense"))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "dense")
        self.assertEqual(set(attr.GetMetadata("allowedTokens")), {"sparse", "dense", "fixed"})

    def test_grid_padding(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:gridPadding")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 0)

        self.assertTrue(attr.Set(2))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 2)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), 0)
            self.assertIsNone(hard.GetMaximum())

    def test_max_active_cell_count(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:maxActiveCellCount")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -1)

        self.assertTrue(attr.Set(1024))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 1024)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), -1)
            self.assertIsNone(hard.GetMaximum())

    def test_transfer_scheme(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:transferScheme")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "apic")

        self.assertTrue(attr.Set("pic"))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "pic")
        self.assertEqual(set(attr.GetMetadata("allowedTokens")), {"apic", "pic"})

    def test_integration_scheme(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:integrationScheme")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "pic")

        self.assertTrue(attr.Set("gimp"))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "gimp")
        self.assertEqual(set(attr.GetMetadata("allowedTokens")), {"pic", "gimp"})

    def test_critical_fraction(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:criticalFraction")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        self.assertTrue(attr.Set(0.25))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.25)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertAlmostEqual(hard.GetMaximum(), 1.0)

    def test_air_drag(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:airDrag")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        self.assertTrue(attr.Set(0.1))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.1)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_collider_basis_type(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:colliderBasisType")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "serendipity")

        self.assertTrue(attr.Set("particle"))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "particle")
        self.assertEqual(
            set(attr.GetMetadata("allowedTokens")),
            {"linear", "trilinear", "bspline", "serendipity", "particle"},
        )

    def test_collider_basis_order(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:colliderBasisOrder")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 2)

        self.assertTrue(attr.Set(3))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 3)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), 0)
            self.assertIsNone(hard.GetMaximum())

    def test_collider_discontinuous_basis(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:colliderDiscontinuousBasis")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), False)

        self.assertTrue(attr.Set(True))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), True)

    def test_strain_basis_type(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:strainBasisType")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "linear")

        self.assertTrue(attr.Set("trilinear"))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "trilinear")
        self.assertEqual(
            set(attr.GetMetadata("allowedTokens")),
            {"linear", "trilinear", "particle"},
        )

    def test_strain_basis_order(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:strainBasisOrder")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 0)

        self.assertTrue(attr.Set(1))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 1)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), 0)
            self.assertIsNone(hard.GetMaximum())

    def test_strain_discontinuous_basis(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:strainDiscontinuousBasis")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), False)

        self.assertTrue(attr.Set(True))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), True)

    def test_velocity_basis_type(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:velocityBasisType")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "trilinear")

        self.assertTrue(attr.Set("bspline"))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "bspline")
        self.assertEqual(set(attr.GetMetadata("allowedTokens")), {"trilinear", "bspline"})

    def test_velocity_basis_order(self):
        self.scene.ApplyAPI("DynaSphereMPMSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:mpm:velocityBasisOrder")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 1)

        self.assertTrue(attr.Set(3))
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 3)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), 1)
            self.assertEqual(hard.GetMaximum(), 3)


if __name__ == "__main__":
    unittest.main()
