# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import math
import unittest

from pxr import Plug, Usd, UsdPhysics, UsdShade

import dynasphere_usd_schemas  # noqa: F401

USD_HAS_LIMITS = Usd.GetVersion() >= (0, 25, 11)


class TestDynaSphereMaterialAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.material: UsdPhysics.Material = UsdShade.Material.Define(self.stage, "/Material").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsMaterialAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsMaterialAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsMaterialAPI")
        self.assertEqual(schema_type, "DynaSphereMaterialAPI")

    def test_api_application(self):
        self.assertFalse(self.material.HasAPI("PhysicsMaterialAPI"))
        self.assertFalse(self.material.HasAPI("DynaSphereMaterialAPI"))
        self.material.ApplyAPI("DynaSphereMaterialAPI")
        self.assertTrue(self.material.HasAPI("PhysicsMaterialAPI"))
        self.assertTrue(self.material.HasAPI("DynaSphereMaterialAPI"))

        self.assertTrue(self.material.HasAttribute("physics:dynamicFriction"))  # from PhysicsMaterialAPI
        self.assertTrue(self.material.HasAttribute("dynasphere:torsionalFriction"))  # from DynaSphereMaterialAPI
        self.assertTrue(self.material.HasAttribute("dynasphere:contactStiffness"))  # from DynaSphereMaterialAPI
        self.assertTrue(self.material.HasAttribute("dynasphere:contactDamping"))  # from DynaSphereMaterialAPI
        self.assertTrue(self.material.HasAttribute("dynasphere:contactFrictionGain"))  # from DynaSphereMaterialAPI
        self.assertTrue(self.material.HasAttribute("dynasphere:contactAdhesion"))  # from DynaSphereMaterialAPI

    def test_api_limitations(self):
        prim: Usd.Prim = self.stage.DefinePrim("/NotMaterial", "Xform")
        self.assertFalse(prim.CanApplyAPI("DynaSphereMaterialAPI"))

    def test_torsional_friction(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:torsionalFriction"))

        self.material.ApplyAPI("DynaSphereMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:torsionalFriction")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.005)

        success = attr.Set(0.1)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.1)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_rolling_friction(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:rollingFriction"))

        self.material.ApplyAPI("DynaSphereMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:rollingFriction")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0001)

        success = attr.Set(0.01)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.01)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_contact_stiffness(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:contactStiffness"))

        self.material.ApplyAPI("DynaSphereMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:contactStiffness")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(5000.0)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 5000.0)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_contact_damping(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:contactDamping"))

        self.material.ApplyAPI("DynaSphereMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:contactDamping")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(200.0)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 200.0)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_contact_friction_stiffness(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:contactFrictionGain"))

        self.material.ApplyAPI("DynaSphereMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:contactFrictionGain")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(2000.0)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 2000.0)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_contact_adhesion(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:contactAdhesion"))

        self.material.ApplyAPI("DynaSphereMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:contactAdhesion")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(0.05)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.05)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())


if __name__ == "__main__":
    unittest.main()
