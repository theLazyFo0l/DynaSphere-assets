# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import pathlib
import unittest

from pxr import Plug

import dynasphere_usd_schemas


class TestDynaSpherePlugin(unittest.TestCase):
    def test_dynasphere_plugin_registered(self):
        plugin = Plug.Registry().GetPluginWithName("dynasphere")
        self.assertIsInstance(plugin, Plug.Plugin)
        self.assertEqual(plugin.resourcePath, pathlib.Path(dynasphere_usd_schemas.__file__).parent.as_posix())


if __name__ == "__main__":
    unittest.main()
