# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import unittest

from pxr import Plug, Usd, UsdGeom

import dynasphere_usd_schemas  # noqa: F401


class TestDynaSphereSiteAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = UsdGeom.Sphere.Define(self.stage, "/Site").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsSiteAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsSiteAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsSiteAPI")
        self.assertEqual(schema_type, "DynaSphereSiteAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSphereSiteAPI"))
        self.prim.ApplyAPI("DynaSphereSiteAPI")
        self.assertTrue(self.prim.HasAPI("DynaSphereSiteAPI"))

    def test_presence_only(self):
        self.prim.ApplyAPI("DynaSphereSiteAPI")
        site_attrs = [a for a in self.prim.GetAttributes() if a.GetName().startswith("dynasphere:")]
        self.assertEqual(len(site_attrs), 0)

    def test_does_not_inherit_collision(self):
        self.prim.ApplyAPI("DynaSphereSiteAPI")
        self.assertFalse(self.prim.HasAPI("PhysicsCollisionAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereCollisionAPI"))

    def test_api_limitations(self):
        xform: Usd.Prim = UsdGeom.Xform.Define(self.stage, "/InvalidType").GetPrim()
        self.assertFalse(xform.CanApplyAPI("DynaSphereSiteAPI"))

    def test_applies_to_various_gprims(self):
        cube = UsdGeom.Cube.Define(self.stage, "/Cube").GetPrim()
        self.assertTrue(cube.CanApplyAPI("DynaSphereSiteAPI"))
        cube.ApplyAPI("DynaSphereSiteAPI")
        self.assertTrue(cube.HasAPI("DynaSphereSiteAPI"))

        mesh = UsdGeom.Mesh.Define(self.stage, "/Mesh").GetPrim()
        self.assertTrue(mesh.CanApplyAPI("DynaSphereSiteAPI"))

        capsule = UsdGeom.Capsule.Define(self.stage, "/Capsule").GetPrim()
        self.assertTrue(capsule.CanApplyAPI("DynaSphereSiteAPI"))

    def test_removal(self):
        self.prim.ApplyAPI("DynaSphereSiteAPI")
        self.assertTrue(self.prim.HasAPI("DynaSphereSiteAPI"))
        self.prim.RemoveAPI("DynaSphereSiteAPI")
        self.assertFalse(self.prim.HasAPI("DynaSphereSiteAPI"))


if __name__ == "__main__":
    unittest.main()
