# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import math
import unittest

from pxr import Plug, Usd, UsdGeom

import dynasphere_usd_schemas  # noqa: F401

USD_HAS_LIMITS = Usd.GetVersion() >= (0, 25, 11)


class TestDynaSphereCollisionAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = UsdGeom.Cube.Define(self.stage, "/Collider").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsCollisionAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsCollisionAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsCollisionAPI")
        self.assertEqual(schema_type, "DynaSphereCollisionAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("PhysicsCollisionAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereCollisionAPI"))
        self.prim.ApplyAPI("DynaSphereCollisionAPI")
        self.assertTrue(self.prim.HasAPI("PhysicsCollisionAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereCollisionAPI"))

        self.assertTrue(self.prim.HasAttribute("physics:collisionEnabled"))  # from PhysicsCollisionAPI
        self.assertTrue(self.prim.HasAttribute("dynasphere:contactMargin"))  # from DynaSphereCollisionAPI
        self.assertTrue(self.prim.HasAttribute("dynasphere:contactGap"))  # from DynaSphereCollisionAPI
        # SDF/hydro attrs should NOT be present on bare DynaSphereCollisionAPI
        self.assertFalse(self.prim.HasAttribute("dynasphere:sdfMaxResolution"))
        self.assertFalse(self.prim.HasAttribute("dynasphere:hydroelasticStiffness"))

    def test_api_limitations(self):
        xform: Usd.Prim = UsdGeom.Xform.Define(self.stage, "/InvalidType").GetPrim()
        self.assertFalse(xform.CanApplyAPI("DynaSphereCollisionAPI"))

    def test_contact_margin(self):
        self.assertFalse(self.prim.HasAttribute("dynasphere:contactMargin"))

        self.prim.ApplyAPI("DynaSphereCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:contactMargin")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        success = attr.Set(0.2)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.2)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_contact_gap(self):
        self.assertFalse(self.prim.HasAttribute("dynasphere:contactGap"))

        self.prim.ApplyAPI("DynaSphereCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:contactGap")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(0.1)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.1)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())


class TestDynaSphereSDFCollisionAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = UsdGeom.Cube.Define(self.stage, "/Collider").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsSDFCollisionAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsSDFCollisionAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsSDFCollisionAPI")
        self.assertEqual(schema_type, "DynaSphereSDFCollisionAPI")

    def test_api_application(self):
        self.prim.ApplyAPI("DynaSphereSDFCollisionAPI")
        # Should inherit DynaSphereCollisionAPI and PhysicsCollisionAPI
        self.assertTrue(self.prim.HasAPI("DynaSphereSDFCollisionAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereCollisionAPI"))
        self.assertTrue(self.prim.HasAPI("PhysicsCollisionAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereMeshCollisionAPI"))

        # SDF attrs
        self.assertTrue(self.prim.HasAttribute("dynasphere:sdfMaxResolution"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:sdfTargetVoxelSize"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:sdfNarrowBandInner"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:sdfNarrowBandOuter"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:sdfTextureFormat"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:sdfPadding"))
        # Hydroelastic attrs are folded into this API
        self.assertTrue(self.prim.HasAttribute("dynasphere:hydroelasticEnabled"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:hydroelasticStiffness"))
        # Inherited from DynaSphereCollisionAPI
        self.assertTrue(self.prim.HasAttribute("dynasphere:contactMargin"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:contactGap"))

    def test_api_limitations(self):
        xform: Usd.Prim = UsdGeom.Xform.Define(self.stage, "/InvalidType").GetPrim()
        self.assertFalse(xform.CanApplyAPI("DynaSphereSDFCollisionAPI"))

    def test_sdf_max_resolution(self):
        self.prim.ApplyAPI("DynaSphereSDFCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:sdfMaxResolution")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 64)

        attr.Set(128)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 128)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), 8)
            self.assertIsNone(hard.GetMaximum())

    def test_sdf_target_voxel_size(self):
        self.prim.ApplyAPI("DynaSphereSDFCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:sdfTargetVoxelSize")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        attr.Set(0.005)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.005)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_sdf_narrow_band_inner(self):
        self.prim.ApplyAPI("DynaSphereSDFCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:sdfNarrowBandInner")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), -0.1)

        attr.Set(-0.02)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), -0.02)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertIsNone(soft.GetMinimum())
            self.assertAlmostEqual(soft.GetMaximum(), 0.0)

    def test_sdf_narrow_band_outer(self):
        self.prim.ApplyAPI("DynaSphereSDFCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:sdfNarrowBandOuter")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.1)

        attr.Set(0.02)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.02)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_sdf_texture_format(self):
        self.prim.ApplyAPI("DynaSphereSDFCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:sdfTextureFormat")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "uint16")

        attr.Set("float32")
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), "float32")

    def test_sdf_padding(self):
        self.prim.ApplyAPI("DynaSphereSDFCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:sdfPadding")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        attr.Set(0.05)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.05)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_hydroelastic_enabled(self):
        self.prim.ApplyAPI("DynaSphereSDFCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:hydroelasticEnabled")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertFalse(attr.Get())  # opt-in: defaults to false

        attr.Set(True)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertTrue(attr.Get())

    def test_hydroelastic_stiffness(self):
        self.prim.ApplyAPI("DynaSphereSDFCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:hydroelasticStiffness")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 1e10)

        attr.Set(1e7)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 1e7)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())


class TestDynaSphereMeshCollisionAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = UsdGeom.Mesh.Define(self.stage, "/Collider").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsMeshCollisionAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsMeshCollisionAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsMeshCollisionAPI")
        self.assertEqual(schema_type, "DynaSphereMeshCollisionAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("PhysicsCollisionAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereCollisionAPI"))
        self.assertFalse(self.prim.HasAPI("PhysicsMeshCollisionAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereMeshCollisionAPI"))
        self.prim.ApplyAPI("DynaSphereMeshCollisionAPI")
        self.assertTrue(self.prim.HasAPI("PhysicsCollisionAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereCollisionAPI"))
        self.assertTrue(self.prim.HasAPI("PhysicsMeshCollisionAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereMeshCollisionAPI"))

        self.assertTrue(self.prim.HasAttribute("physics:collisionEnabled"))  # from PhysicsCollisionAPI
        self.assertTrue(self.prim.HasAttribute("dynasphere:contactMargin"))  # from DynaSphereCollisionAPI
        self.assertTrue(self.prim.HasAttribute("dynasphere:contactGap"))  # from DynaSphereCollisionAPI
        self.assertTrue(self.prim.HasAttribute("physics:approximation"))  # from PhysicsMeshCollisionAPI
        self.assertTrue(self.prim.HasAttribute("dynasphere:maxHullVertices"))  # from DynaSphereMeshCollisionAPI

    def test_api_limitations(self):
        sphere: Usd.Prim = UsdGeom.Sphere.Define(self.stage, "/Sphere").GetPrim()
        self.assertFalse(sphere.CanApplyAPI("DynaSphereMeshCollisionAPI"))

    def test_max_hull_vertices(self):
        self.assertFalse(self.prim.HasAttribute("dynasphere:maxHullVertices"))
        self.prim.ApplyAPI("DynaSphereMeshCollisionAPI")
        attr = self.prim.GetAttribute("dynasphere:maxHullVertices")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -1)

        success = attr.Set(100)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 100)

        # Test rounding down to the nearest integer
        success = attr.Set(0.9)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 0)

        # Test setting to -1
        success = attr.Set(-1)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -1)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), -1)
            self.assertIsNone(hard.GetMaximum())


if __name__ == "__main__":
    unittest.main()
