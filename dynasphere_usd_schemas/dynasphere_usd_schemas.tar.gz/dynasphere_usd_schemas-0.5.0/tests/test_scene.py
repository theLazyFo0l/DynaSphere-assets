# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import unittest

from pxr import Plug, Usd, UsdPhysics

import dynasphere_usd_schemas  # noqa: F401

USD_HAS_LIMITS = Usd.GetVersion() >= (0, 25, 11)


class TestDynaSphereSceneAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.scene: Usd.Prim = UsdPhysics.Scene.Define(self.stage, "/Scene").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsSceneAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsSceneAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsSceneAPI")
        self.assertEqual(schema_type, "DynaSphereSceneAPI")

    def test_api_application(self):
        self.scene.ApplyAPI("DynaSphereSceneAPI")
        self.assertTrue(self.scene.HasAPI("DynaSphereSceneAPI"))

    def test_api_limitations(self):
        prim: Usd.Prim = self.stage.DefinePrim("/NotScene", "Xform")
        self.assertFalse(prim.CanApplyAPI("DynaSphereSceneAPI"))

    def test_max_solver_iterations(self):
        self.assertFalse(self.scene.HasAttribute("dynasphere:maxSolverIterations"))

        self.scene.ApplyAPI("DynaSphereSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:maxSolverIterations")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -1)

        success = attr.Set(10)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 10)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), -1)
            self.assertIsNone(hard.GetMaximum())

    def test_time_steps_per_second(self):
        self.assertFalse(self.scene.HasAttribute("dynasphere:timeStepsPerSecond"))

        self.scene.ApplyAPI("DynaSphereSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:timeStepsPerSecond")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 1000)

        success = attr.Set(10000)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 10000)

        # Test rounding down to the nearest integer
        success = attr.Set(0.9)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), 1)
            self.assertIsNone(hard.GetMaximum())

    def test_enable_gravity(self):
        self.assertFalse(self.scene.HasAttribute("dynasphere:gravityEnabled"))

        self.scene.ApplyAPI("DynaSphereSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:gravityEnabled")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), True)

        success = attr.Set(False)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), False)


if __name__ == "__main__":
    unittest.main()
