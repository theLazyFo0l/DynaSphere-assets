# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import unittest

from pxr import Plug, Usd, UsdPhysics

import dynasphere_usd_schemas  # noqa: F401

USD_HAS_LIMITS = Usd.GetVersion() >= (0, 25, 11)


class TestDynaSphereXpbdSceneAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.scene: Usd.Prim = UsdPhysics.Scene.Define(self.stage, "/Scene").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsXpbdSceneAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsXpbdSceneAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsXpbdSceneAPI")
        self.assertEqual(schema_type, "DynaSphereXpbdSceneAPI")

    def test_api_application(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        self.assertTrue(self.scene.HasAPI("DynaSphereSceneAPI"))
        self.assertTrue(self.scene.HasAPI("DynaSphereXpbdSceneAPI"))

    def test_api_limitations(self):
        prim: Usd.Prim = self.stage.DefinePrim("/NotScene", "Xform")
        self.assertFalse(prim.CanApplyAPI("DynaSphereXpbdSceneAPI"))

    def test_soft_body_relaxation(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:softBodyRelaxation")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 0.9, places=5)

        success = attr.Set(0.8)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 0.8, places=5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertAlmostEqual(hard.GetMaximum(), 1.0)

    def test_soft_contact_relaxation(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:softContactRelaxation")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 0.9, places=5)

        success = attr.Set(0.75)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 0.75, places=5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertAlmostEqual(hard.GetMaximum(), 1.0)

    def test_joint_linear_relaxation(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:jointLinearRelaxation")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 0.7, places=5)

        success = attr.Set(0.5)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 0.5, places=5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertAlmostEqual(hard.GetMaximum(), 1.0)

    def test_joint_angular_relaxation(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:jointAngularRelaxation")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 0.4, places=5)

        success = attr.Set(0.3)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 0.3, places=5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertAlmostEqual(hard.GetMaximum(), 1.0)

    def test_joint_linear_compliance(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:jointLinearCompliance")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 0.0, places=5)

        success = attr.Set(0.001)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 0.001, places=5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_joint_angular_compliance(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:jointAngularCompliance")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 0.0, places=5)

        success = attr.Set(0.002)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 0.002, places=5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_rigid_contact_relaxation(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:rigidContactRelaxation")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 0.8, places=5)

        success = attr.Set(0.9)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 0.9, places=5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertAlmostEqual(hard.GetMaximum(), 1.0)

    def test_rigid_contact_con_weighting(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:rigidContactConWeighting")
        self.assertIsNotNone(attr)
        self.assertEqual(attr.Get(), True)

        success = attr.Set(False)
        self.assertTrue(success)
        self.assertEqual(attr.Get(), False)

    def test_angular_damping(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:angularDamping")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 0.0, places=5)

        success = attr.Set(0.1)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 0.1, places=5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_restitution_enabled(self):
        self.scene.ApplyAPI("DynaSphereXpbdSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:xpbd:restitutionEnabled")
        self.assertIsNotNone(attr)
        self.assertEqual(attr.Get(), False)

        success = attr.Set(True)
        self.assertTrue(success)
        self.assertEqual(attr.Get(), True)


if __name__ == "__main__":
    unittest.main()
