# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import math
import unittest

from pxr import Plug, Usd, UsdShade

import dynasphere_usd_schemas  # noqa: F401

USD_HAS_LIMITS = Usd.GetVersion() >= (0, 25, 11)


class TestDynaSphereCurvesDeformableMaterialAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.material = UsdShade.Material.Define(self.stage, "/CableMaterial").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsCurvesDeformableMaterialAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsCurvesDeformableMaterialAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsCurvesDeformableMaterialAPI")
        self.assertEqual(schema_type, "DynaSphereCurvesDeformableMaterialAPI")

    def test_api_application(self):
        self.assertFalse(self.material.HasAPI("DynaSphereCurvesDeformableMaterialAPI"))
        self.material.ApplyAPI("DynaSphereCurvesDeformableMaterialAPI")
        self.assertTrue(self.material.HasAPI("PhysicsMaterialAPI"))
        self.assertTrue(self.material.HasAPI("DynaSphereCurvesDeformableMaterialAPI"))

        for name in (
            "dynasphere:curvesStretchDamping",
            "dynasphere:curvesShearDamping",
            "dynasphere:curvesBendDamping",
            "dynasphere:curvesTwistDamping",
        ):
            self.assertTrue(self.material.HasAttribute(name), name)

    def test_api_limitations(self):
        prim = self.stage.DefinePrim("/NotMaterial", "Xform")
        self.assertFalse(prim.CanApplyAPI("DynaSphereCurvesDeformableMaterialAPI"))
        self.assertTrue(self.material.CanApplyAPI("DynaSphereCurvesDeformableMaterialAPI"))

    def test_curves_stretch_damping(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:curvesStretchDamping"))

        self.material.ApplyAPI("DynaSphereCurvesDeformableMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:curvesStretchDamping")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(0.01)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.01)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_curves_shear_damping(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:curvesShearDamping"))

        self.material.ApplyAPI("DynaSphereCurvesDeformableMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:curvesShearDamping")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(0.02)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.02)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_curves_bend_damping(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:curvesBendDamping"))

        self.material.ApplyAPI("DynaSphereCurvesDeformableMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:curvesBendDamping")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(0.03)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.03)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())

    def test_curves_twist_damping(self):
        self.assertFalse(self.material.HasAttribute("dynasphere:curvesTwistDamping"))

        self.material.ApplyAPI("DynaSphereCurvesDeformableMaterialAPI")
        attr = self.material.GetAttribute("dynasphere:curvesTwistDamping")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), -math.inf)

        success = attr.Set(0.04)
        self.assertTrue(success)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.04)

        if USD_HAS_LIMITS:
            soft = attr.GetSoftLimits()
            self.assertTrue(soft.IsValid())
            self.assertAlmostEqual(soft.GetMinimum(), 0.0)
            self.assertIsNone(soft.GetMaximum())


if __name__ == "__main__":
    unittest.main()
