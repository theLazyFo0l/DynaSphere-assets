# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import math
import unittest

from pxr import Plug, Sdf, Usd, UsdGeom

import dynasphere_usd_schemas  # noqa: F401

USD_HAS_LIMITS = Usd.GetVersion() >= (0, 25, 11)


class TestDynaSphereActuator(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_typed_schema_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsActuator")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsActuator")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsActuator")
        self.assertEqual(schema_type, "DynaSphereActuator")

    def test_prim_is_actuator(self):
        self.assertEqual(self.prim.GetTypeName(), "DynaSphereActuator")
        self.assertTrue(self.prim.IsValid())
        self.assertTrue(self.prim.HasRelationship("dynasphere:targets"))

    def test_targets_relationship(self):
        rel = self.prim.GetRelationship("dynasphere:targets")
        self.assertFalse(rel.HasAuthoredTargets())
        rel.SetTargets([Sdf.Path("/World/Joint")])
        targets = rel.GetTargets()
        self.assertEqual(len(targets), 1)
        self.assertEqual(str(targets[0]), "/World/Joint")

    def test_not_imageable(self):
        # Actuators carry a control law bound to a joint; they have no extent and are
        # never rendered, so they derive from UsdTyped rather than UsdGeomImageable.
        self.assertFalse(self.prim.IsA(UsdGeom.Imageable))

        # The prim definition must not advertise Imageable properties it does not have.
        definition = Usd.SchemaRegistry().FindConcretePrimDefinition("DynaSphereActuator")
        self.assertIsNotNone(definition)
        self.assertEqual(sorted(definition.GetPropertyNames()), ["dynasphere:targets"])

    def test_bbox_cache_skips_actuator(self):
        # Regression test: when DynaSphereActuator declared UsdGeomImageable as its base
        # without baking in the inherited visibility/purpose/proxyPrim properties,
        # UsdGeom.BBoxCache treated the prim as Imageable and then failed to read its
        # visibility attribute, raising from _GetOrCreateVisibilityQuery.
        root = self.stage.DefinePrim("/World", "Xform")
        self.stage.DefinePrim("/World/Actuator", "DynaSphereActuator")
        cache = UsdGeom.BBoxCache(Usd.TimeCode.Default(), [UsdGeom.Tokens.default_])
        bound = cache.ComputeWorldBound(root)
        self.assertTrue(bound.GetRange().IsEmpty())


class TestDynaSphereActuatorDelayAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsActuatorDelayAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsActuatorDelayAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsActuatorDelayAPI")
        self.assertEqual(schema_type, "DynaSphereActuatorDelayAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSphereActuatorDelayAPI"))
        self.prim.ApplyAPI("DynaSphereActuatorDelayAPI")
        self.assertTrue(self.prim.HasAPI("DynaSphereActuatorDelayAPI"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:delaySteps"))

    def test_delay_steps(self):
        self.prim.ApplyAPI("DynaSphereActuatorDelayAPI")
        attr = self.prim.GetAttribute("dynasphere:delaySteps")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 1)

        attr.Set(0)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), 0)

        attr.Set(5)
        self.assertEqual(attr.Get(), 5)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertEqual(hard.GetMinimum(), 0)
            self.assertIsNone(hard.GetMaximum())

    def test_api_limitations(self):
        xform = self.stage.DefinePrim("/NotActuator", "Xform")
        self.assertFalse(xform.CanApplyAPI("DynaSphereActuatorDelayAPI"))


class TestDynaSphereActuatorControlBaseAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsActuatorControlBaseAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsActuatorControlBaseAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsActuatorControlBaseAPI")
        self.assertEqual(schema_type, "DynaSphereActuatorControlBaseAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSphereActuatorControlBaseAPI"))
        self.prim.ApplyAPI("DynaSphereActuatorControlBaseAPI")
        self.assertTrue(self.prim.HasAPI("DynaSphereActuatorControlBaseAPI"))

    def test_api_limitations(self):
        xform = self.stage.DefinePrim("/NotActuator", "Xform")
        self.assertFalse(xform.CanApplyAPI("DynaSphereActuatorControlBaseAPI"))


class TestDynaSpherePDControlAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsPDControlAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsPDControlAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsPDControlAPI")
        self.assertEqual(schema_type, "DynaSpherePDControlAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSpherePDControlAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereActuatorControlBaseAPI"))
        self.prim.ApplyAPI("DynaSpherePDControlAPI")
        self.assertTrue(self.prim.HasAPI("DynaSpherePDControlAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereActuatorControlBaseAPI"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:kp"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:kd"))

    def test_kp(self):
        self.prim.ApplyAPI("DynaSpherePDControlAPI")
        attr = self.prim.GetAttribute("dynasphere:kp")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        attr.Set(50.0)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 50.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_kd(self):
        self.prim.ApplyAPI("DynaSpherePDControlAPI")
        attr = self.prim.GetAttribute("dynasphere:kd")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        attr.Set(5.0)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 5.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())


class TestDynaSpherePIDControlAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsPIDControlAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsPIDControlAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsPIDControlAPI")
        self.assertEqual(schema_type, "DynaSpherePIDControlAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSpherePIDControlAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereActuatorControlBaseAPI"))
        self.prim.ApplyAPI("DynaSpherePIDControlAPI")
        self.assertTrue(self.prim.HasAPI("DynaSpherePIDControlAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereActuatorControlBaseAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSpherePDControlAPI"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:kp"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:kd"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:ki"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:integralMax"))

    def test_kp(self):
        self.prim.ApplyAPI("DynaSpherePDControlAPI")
        attr = self.prim.GetAttribute("dynasphere:kp")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        attr.Set(50.0)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 50.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_kd(self):
        self.prim.ApplyAPI("DynaSpherePDControlAPI")
        attr = self.prim.GetAttribute("dynasphere:kd")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        attr.Set(5.0)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 5.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_ki(self):
        self.prim.ApplyAPI("DynaSpherePIDControlAPI")
        attr = self.prim.GetAttribute("dynasphere:ki")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 0.0)

        attr.Set(10.0)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 10.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_integral_max(self):
        self.prim.ApplyAPI("DynaSpherePIDControlAPI")
        attr = self.prim.GetAttribute("dynasphere:integralMax")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), math.inf)

        attr.Set(100.0)
        self.assertAlmostEqual(attr.Get(), 100.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())


class TestDynaSphereNeuralControlAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsNeuralControlAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsNeuralControlAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsNeuralControlAPI")
        self.assertEqual(schema_type, "DynaSphereNeuralControlAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSphereNeuralControlAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereActuatorControlBaseAPI"))
        self.prim.ApplyAPI("DynaSphereNeuralControlAPI")
        self.assertTrue(self.prim.HasAPI("DynaSphereNeuralControlAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereActuatorControlBaseAPI"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:modelPath"))

    def test_model_path(self):
        self.prim.ApplyAPI("DynaSphereNeuralControlAPI")
        attr = self.prim.GetAttribute("dynasphere:modelPath")
        self.assertFalse(attr.HasAuthoredValue())

        attr.Set("path/to/model.pt")
        self.assertTrue(attr.HasAuthoredValue())
        self.assertEqual(attr.Get().path, "path/to/model.pt")

    def test_api_limitations(self):
        xform = self.stage.DefinePrim("/NotActuator", "Xform")
        self.assertFalse(xform.CanApplyAPI("DynaSphereNeuralControlAPI"))


class TestDynaSphereActuatorClampingBaseAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsActuatorClampingBaseAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsActuatorClampingBaseAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsActuatorClampingBaseAPI")
        self.assertEqual(schema_type, "DynaSphereActuatorClampingBaseAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSphereActuatorClampingBaseAPI"))
        self.prim.ApplyAPI("DynaSphereActuatorClampingBaseAPI")
        self.assertTrue(self.prim.HasAPI("DynaSphereActuatorClampingBaseAPI"))

    def test_api_limitations(self):
        xform = self.stage.DefinePrim("/NotActuator", "Xform")
        self.assertFalse(xform.CanApplyAPI("DynaSphereActuatorClampingBaseAPI"))


class TestDynaSphereMaxEffortClampingAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsMaxEffortClampingAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsMaxEffortClampingAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsMaxEffortClampingAPI")
        self.assertEqual(schema_type, "DynaSphereMaxEffortClampingAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSphereMaxEffortClampingAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereActuatorClampingBaseAPI"))
        self.prim.ApplyAPI("DynaSphereMaxEffortClampingAPI")
        self.assertTrue(self.prim.HasAPI("DynaSphereMaxEffortClampingAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereActuatorClampingBaseAPI"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:maxEffort"))

    def test_max_effort(self):
        self.prim.ApplyAPI("DynaSphereMaxEffortClampingAPI")
        attr = self.prim.GetAttribute("dynasphere:maxEffort")
        self.assertIsNotNone(attr)
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), math.inf)

        attr.Set(100.0)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 100.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_api_limitations(self):
        xform = self.stage.DefinePrim("/NotActuator", "Xform")
        self.assertFalse(xform.CanApplyAPI("DynaSphereMaxEffortClampingAPI"))


class TestDynaSphereDCMotorClampingAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsDCMotorClampingAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsDCMotorClampingAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsDCMotorClampingAPI")
        self.assertEqual(schema_type, "DynaSphereDCMotorClampingAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSphereDCMotorClampingAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereActuatorClampingBaseAPI"))
        self.prim.ApplyAPI("DynaSphereDCMotorClampingAPI")
        self.assertTrue(self.prim.HasAPI("DynaSphereDCMotorClampingAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereActuatorClampingBaseAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereMaxEffortClampingAPI"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:maxMotorEffort"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:saturationEffort"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:velocityLimit"))

    def test_max_motor_effort(self):
        self.prim.ApplyAPI("DynaSphereDCMotorClampingAPI")
        attr = self.prim.GetAttribute("dynasphere:maxMotorEffort")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), math.inf)

        attr.Set(100.0)
        self.assertAlmostEqual(attr.Get(), 100.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_saturation_effort(self):
        self.prim.ApplyAPI("DynaSphereDCMotorClampingAPI")
        attr = self.prim.GetAttribute("dynasphere:saturationEffort")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), math.inf)

        attr.Set(10.0)
        self.assertAlmostEqual(attr.Get(), 10.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_velocity_limit(self):
        self.prim.ApplyAPI("DynaSphereDCMotorClampingAPI")
        attr = self.prim.GetAttribute("dynasphere:velocityLimit")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), math.inf)

        attr.Set(30.0)
        self.assertTrue(attr.HasAuthoredValue())
        self.assertAlmostEqual(attr.Get(), 30.0)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertIsNone(hard.GetMaximum())

    def test_api_limitations(self):
        xform = self.stage.DefinePrim("/NotActuator", "Xform")
        self.assertFalse(xform.CanApplyAPI("DynaSphereDCMotorClampingAPI"))


class TestDynaSpherePositionBasedClampingAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.prim: Usd.Prim = self.stage.DefinePrim("/Actuator", "DynaSphereActuator")

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsPositionBasedClampingAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsPositionBasedClampingAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsPositionBasedClampingAPI")
        self.assertEqual(schema_type, "DynaSpherePositionBasedClampingAPI")

    def test_api_application(self):
        self.assertFalse(self.prim.HasAPI("DynaSpherePositionBasedClampingAPI"))
        self.assertFalse(self.prim.HasAPI("DynaSphereActuatorClampingBaseAPI"))
        self.prim.ApplyAPI("DynaSpherePositionBasedClampingAPI")
        self.assertTrue(self.prim.HasAPI("DynaSpherePositionBasedClampingAPI"))
        self.assertTrue(self.prim.HasAPI("DynaSphereActuatorClampingBaseAPI"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:lookupPositions"))
        self.assertTrue(self.prim.HasAttribute("dynasphere:lookupEfforts"))

    def test_lookup_positions(self):
        self.prim.ApplyAPI("DynaSpherePositionBasedClampingAPI")
        attr = self.prim.GetAttribute("dynasphere:lookupPositions")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), [])

        attr.Set([0.0, 45.0, 90.0])
        self.assertEqual(attr.Get(), [0.0, 45.0, 90.0])

    def test_lookup_efforts(self):
        self.prim.ApplyAPI("DynaSpherePositionBasedClampingAPI")
        attr = self.prim.GetAttribute("dynasphere:lookupEfforts")
        self.assertFalse(attr.HasAuthoredValue())
        self.assertEqual(attr.Get(), [])

        attr.Set([100.0, 80.0, 50.0])
        self.assertEqual(attr.Get(), [100.0, 80.0, 50.0])

    def test_api_limitations(self):
        xform = self.stage.DefinePrim("/NotActuator", "Xform")
        self.assertFalse(xform.CanApplyAPI("DynaSpherePositionBasedClampingAPI"))


if __name__ == "__main__":
    unittest.main()
