# SPDX-FileCopyrightText: Copyright (c) 2025 USTB_Ai3D_theLazyFo0l
# SPDX-License-Identifier: Apache-2.0

import unittest

from pxr import Plug, Usd, UsdPhysics

import dynasphere_usd_schemas  # noqa: F401

USD_HAS_LIMITS = Usd.GetVersion() >= (0, 25, 11)


class TestDynaSphereKaminoSceneAPI(unittest.TestCase):
    def setUp(self):
        self.stage: Usd.Stage = Usd.Stage.CreateInMemory()
        self.scene: Usd.Prim = UsdPhysics.Scene.Define(self.stage, "/Scene").GetPrim()

    def test_api_registered(self):
        plug_type = Plug.Registry().FindTypeByName("DynaSpherePhysicsKaminoSceneAPI")
        self.assertEqual(plug_type.typeName, "DynaSpherePhysicsKaminoSceneAPI")
        schema_type = Usd.SchemaRegistry().GetSchemaTypeName("DynaSpherePhysicsKaminoSceneAPI")
        self.assertEqual(schema_type, "DynaSphereKaminoSceneAPI")

    def test_api_application(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        self.assertTrue(self.scene.HasAPI("DynaSphereSceneAPI"))
        self.assertTrue(self.scene.HasAPI("DynaSphereKaminoSceneAPI"))

    def test_api_limitations(self):
        prim: Usd.Prim = self.stage.DefinePrim("/NotScene", "Xform")
        self.assertFalse(prim.CanApplyAPI("DynaSphereKaminoSceneAPI"))

    def test_padmm_primal_tolerance(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:padmm:primalTolerance")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 1e-6, places=7)

        success = attr.Set(1e-4)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 1e-4, places=7)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 1e-10)
            self.assertIsNone(hard.GetMaximum())

    def test_padmm_dual_tolerance(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:padmm:dualTolerance")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 1e-6, places=7)

        success = attr.Set(1e-4)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 1e-4, places=7)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 1e-10)
            self.assertIsNone(hard.GetMaximum())

    def test_padmm_complementarity_tolerance(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:padmm:complementarityTolerance")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 1e-6, places=7)

        success = attr.Set(1e-4)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 1e-4, places=7)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 1e-10)
            self.assertIsNone(hard.GetMaximum())

    def test_padmm_warmstarting(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:padmm:warmstarting")
        allowed = attr.GetMetadata("allowedTokens")
        self.assertIsNotNone(attr)
        self.assertEqual(attr.Get(), "containers")

        success = attr.Set("internal")
        self.assertTrue(success)
        self.assertEqual(attr.Get(), "internal")

        success = attr.Set("none")
        self.assertTrue(success)
        self.assertEqual(attr.Get(), "none")

        success = "containers" in allowed
        self.assertTrue(success)
        success = "internal" in allowed
        self.assertTrue(success)
        success = "none" in allowed
        self.assertTrue(success)
        success = "foobar" in allowed
        self.assertFalse(success)

    def test_padmm_use_acceleration(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:padmm:useAcceleration")
        self.assertIsNotNone(attr)
        self.assertEqual(attr.Get(), True)

        success = attr.Set(False)
        self.assertTrue(success)
        self.assertEqual(attr.Get(), False)

    def test_constraints_use_preconditioning(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:constraints:usePreconditioning")
        self.assertIsNotNone(attr)
        self.assertEqual(attr.Get(), True)

        success = attr.Set(False)
        self.assertTrue(success)
        self.assertEqual(attr.Get(), False)

    def test_constraints_alpha(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:constraints:alpha")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 1e-2, places=7)

        success = attr.Set(1e-1)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 1e-1, places=7)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertAlmostEqual(hard.GetMaximum(), 1.0)

    def test_constraints_beta(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:constraints:beta")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 1e-2, places=7)

        success = attr.Set(1e-1)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 1e-1, places=7)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertAlmostEqual(hard.GetMaximum(), 1.0)

    def test_constraints_gamma(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:constraints:gamma")
        self.assertIsNotNone(attr)
        self.assertAlmostEqual(attr.Get(), 1e-2, places=7)

        success = attr.Set(1e-1)
        self.assertTrue(success)
        self.assertAlmostEqual(attr.Get(), 1e-1, places=7)

        if USD_HAS_LIMITS:
            hard = attr.GetHardLimits()
            self.assertTrue(hard.IsValid())
            self.assertAlmostEqual(hard.GetMinimum(), 0.0)
            self.assertAlmostEqual(hard.GetMaximum(), 1.0)

    def test_joint_correction(self):
        self.scene.ApplyAPI("DynaSphereKaminoSceneAPI")
        attr = self.scene.GetAttribute("dynasphere:kamino:jointCorrection")
        allowed = attr.GetMetadata("allowedTokens")
        self.assertIsNotNone(attr)
        self.assertEqual(attr.Get(), "twopi")

        success = attr.Set("continuous")
        self.assertTrue(success)
        self.assertEqual(attr.Get(), "continuous")

        success = attr.Set("none")
        self.assertTrue(success)
        self.assertEqual(attr.Get(), "none")

        success = "twopi" in allowed
        self.assertTrue(success)
        success = "continuous" in allowed
        self.assertTrue(success)
        success = "none" in allowed
        self.assertTrue(success)
        success = "foobar" in allowed
        self.assertFalse(success)


if __name__ == "__main__":
    unittest.main()
